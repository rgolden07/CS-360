package com.robertgolden.inventory.data;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;


import com.robertgolden.inventory.R;
import com.robertgolden.inventory.ui.edit.EditItemFragment;
import com.robertgolden.inventory.ui.home.HomeFragment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private List<HashMap> data;
    private LayoutInflater inflater;
    private ClickListener listener;
    private Item item;

    public RecyclerViewAdapter(Context context, List<HashMap> items) {
        this.inflater = LayoutInflater.from(context);
        this.item = new Item(context);
        this.data = items;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        HashMap row = data.get(position);
        Iterator iterator = row.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry entry = (Map.Entry) iterator.next();
            switch (entry.getKey().toString()) {
                case "itemPN":
                    holder.partNumberTextView.setText(entry.getValue().toString());
                    break;
                case "itemDesc":
                    holder.descTextView.setText(entry.getValue().toString());
                    break;
                case "itemQty":
                    holder.qtyTextView.setText(entry.getValue().toString());
                    break;
                case "itemLoc":
                    holder.locTextView.setText(entry.getValue().toString());
                    break;
            }
        }
    }


    @Override
    public int getItemCount() {
        return 0;
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        private TextView partNumberTextView;
        private TextView descTextView;
        private TextView locTextView;
        private TextView qtyTextView;

        RecyclerViewHolder (View entry) {
            super(entry);
            partNumberTextView = entry.findViewById(R.id.itemPN);
            descTextView = entry.findViewById(R.id.itemDesc);
            locTextView = entry.findViewById(R.id.itemLoc);
            qtyTextView = entry.findViewById(R.id.itemQty);

            qtyTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int selectedItemId = (int) itemView.getTag();
                    Bundle args = new Bundle();
                    args.putInt(EditItemFragment.ARG_ITEM_ID, selectedItemId);
                    ItemUpdateClick(view, args);
                }
            });
        }

        @Override
        public void onClick(View view) {
            if(listener != null) listener.itemClicked(view, getAdapterPosition());
        }

    }

    public interface ClickListener {
        void itemClicked(View view, int position);
    }

    private void ItemUpdateClick(View view, Bundle bundle) {
        Navigation.findNavController(view).navigate(R.id.navigation_edit_item, bundle);

    }

}
