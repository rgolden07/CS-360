package com.robertgolden.inventory.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;



public class Item {

    private DatabaseHelper DbHelper;

    public Item(Context context) {
        DbHelper = new DatabaseHelper(context);
    }

    /*
        Private Helpers
    */
    public Cursor queryItemDatabase(String[] projection, @Nullable String selection,
                                    @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        // Get DB
        SQLiteDatabase db = DbHelper.getReadableDatabase();
        // Query and return cursor
        return db.query(
                DatabaseContract.ItemDataTable.TABLE_NAME,          // The table to query
                projection,         // The array of columns to return (pass null to get all)
                selection,          // The columns for the WHERE clause
                selectionArgs,      // The values for the WHERE clause
                null,      // don't group the rows
                null,       // don't filter by row groups
                sortOrder           // The sort order
        );
    }

    public long insertItemDatabase(String partNumber, String description, String quantity, String location) {
        // Get DB
        SQLiteDatabase db = DbHelper.getWritableDatabase();
        // Create content values
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.ItemDataTable.COLUMN_NAME_PARTNUMBER, partNumber);
        values.put(DatabaseContract.ItemDataTable.COLUMN_NAME_DESCRIPTION, description);
        values.put(DatabaseContract.ItemDataTable.COLUMN_NAME_QUANTITY, quantity);
        values.put(DatabaseContract.ItemDataTable.COLUMN_NAME_LOCATION, location);
        // Insert the new row, returning the primary key value of the new row
        return db.insert(DatabaseContract.ItemDataTable.TABLE_NAME, null, values);
    }

    public boolean updateItemDatabase(String productId, String newCount) {
        // Get DB
        SQLiteDatabase db = DbHelper.getWritableDatabase();
        // New value for count column
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.ItemDataTable.COLUMN_NAME_QUANTITY, newCount);
        // Which row to update, based on the title
        String selection = DatabaseContract.ItemDataTable._ID + " LIKE ?";
        String[] selectionArgs = {productId};
        // Call for Update
        return db.update(
                DatabaseContract.ItemDataTable.TABLE_NAME,
                values,
                selection,
                selectionArgs) > 0;
    }

    public boolean deleteItemDatabase(String productId) {
        // Get DB
        SQLiteDatabase db = DbHelper.getWritableDatabase();
        // Build Delete Query
        String selection = DatabaseContract.ItemDataTable._ID + " LIKE ?";
        String[] selectionArgs = {productId};
        // Call for Delete
        return db.delete(
                DatabaseContract.ItemDataTable.TABLE_NAME,
                selection,
                selectionArgs) > 0;
    }

    public boolean deleteAllItemData() {
        // Get DB
        SQLiteDatabase db = DbHelper.getWritableDatabase();
        // Call for Delete
        return db.delete(
                DatabaseContract.ItemDataTable.TABLE_NAME,
                null,
                null) > 0;
    }
}