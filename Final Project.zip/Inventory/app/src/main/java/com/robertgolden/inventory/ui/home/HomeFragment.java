package com.robertgolden.inventory.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.robertgolden.inventory.R;
import com.robertgolden.inventory.data.Item;
import com.robertgolden.inventory.data.RecyclerViewAdapter;
import com.robertgolden.inventory.databinding.FragmentHomeBinding;
import com.robertgolden.inventory.ui.edit.EditItemFragment;

import java.io.IOException;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerViewAdapter adapter;
    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        homeViewModel.GetInstance(getContext());

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        /*View.OnClickListener onClickListener = itemView -> {
            int selectedItemId = (int) itemView.getTag();
            Bundle args = new Bundle();
            args.putInt(EditItemFragment.ARG_ITEM_ID, selectedItemId);

            Navigation.findNavController(itemView).navigate(R.id.navigation_edit_item, args);
        };*/


        RecyclerView recyclerView = root.findViewById(R.id.inventoryList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        try {
            adapter = new RecyclerViewAdapter(getContext(), homeViewModel.GetInventory());
        } catch (IOException e) {
            Snackbar.make(root, "Ahh Ahh Ahh .... You didnt say the magic word.", Snackbar.LENGTH_LONG).show();

        }
        recyclerView.setAdapter(adapter);
       // recyclerView.setAdapter(new RecyclerViewAdapter(items, onClickListener));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /*private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> inventories;
        private final View.OnClickListener onClickListener;

        public ItemAdapter(List<Item> inventories, View.OnClickListener onClickListener) {
            this.inventories = inventories;
            this.onClickListener = onClickListener;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
            Item item = inventories.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getItemID());
            holder.itemView.setOnClickListener(onClickListener);
        }

        @Override
        public int getItemCount() {
            return inventories.size();
        }
    }

    private static class ItemHolder extends RecyclerView.ViewHolder {

        private final TextView partNumberTextView;
        private final TextView descTextView;
        private final TextView locTextView;
        private final TextView qtyTextView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item, parent, false));
            partNumberTextView = itemView.findViewById(R.id.itemPN);
            descTextView = itemView.findViewById(R.id.itemDesc);
            locTextView = itemView.findViewById(R.id.itemLoc);
            qtyTextView = itemView.findViewById(R.id.itemQty);
        }

        public void bind(Item item) {
            partNumberTextView.setText(item.getItemPN());
            descTextView.setText(item.getItemDesc());
            locTextView.setText(item.getItemLoc());
            qtyTextView.setText(item.getItemQty());
        }
    }*/

}