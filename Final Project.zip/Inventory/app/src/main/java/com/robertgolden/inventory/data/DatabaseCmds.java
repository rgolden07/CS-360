package com.robertgolden.inventory.data;

public final class DatabaseCmds {

    public static final String CREATE_DB_SCHEMA ="";
    public static final String CREATE_INV_TABLE =
            "CREATE TABLE " + DatabaseContract.ItemDataTable.TABLE_NAME + " (" +
                    DatabaseContract.ItemDataTable._ID + " INTEGER PRIMARY KEY," +
                    DatabaseContract.ItemDataTable.COLUMN_NAME_PARTNUMBER + " TEXT," +
                    DatabaseContract.ItemDataTable.COLUMN_NAME_DESCRIPTION + " TEXT," +
                    DatabaseContract.ItemDataTable.COLUMN_NAME_QUANTITY + " TEXT," +
                    DatabaseContract.ItemDataTable.COLUMN_NAME_LOCATION + " TEXT)";
    public static final String CREATE_AUTH_TABLE =
            "CREATE TABLE " + DatabaseContract.DatabaseAuth.TABLE_NAME + " (" +
                    DatabaseContract.DatabaseAuth._ID + " INTEGER PRIMARY KEY," +
                    DatabaseContract.DatabaseAuth.COLUMN_NAME_NAME + " TEXT," +
                    DatabaseContract.DatabaseAuth.COLUMN_NAME_USERNAME + " TEXT," +
                    DatabaseContract.DatabaseAuth.COLUMN_NAME_PASSWORD + " TEXT," +
                    DatabaseContract.DatabaseAuth.COLUMN_NAME_LAST_LOGIN + " TEXT)";
}

