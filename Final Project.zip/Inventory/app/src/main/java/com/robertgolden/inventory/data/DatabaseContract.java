package com.robertgolden.inventory.data;

import android.provider.BaseColumns;

public class DatabaseContract {

    private DatabaseContract() {

    }

    public static class DatabaseAuth implements BaseColumns {
        public static final String TABLE_NAME = "authorization";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_USERNAME = "username";
        public static final String COLUMN_NAME_PASSWORD = "password";
        public static final String COLUMN_NAME_LAST_LOGIN = "lastLogin";
    }

    /* Inventory Table */
    public static class ItemDataTable implements BaseColumns {
        public static final String TABLE_NAME = "items";
        public static final String COLUMN_NAME_PARTNUMBER = "partNumber";
        public static final String COLUMN_NAME_DESCRIPTION = "description";
        public static final String COLUMN_NAME_QUANTITY = "quantity";
        public static final String COLUMN_NAME_LOCATION = "location";
    }
}
