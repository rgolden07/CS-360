package com.robertgolden.inventory.ui.edit;

import android.content.Context;

import androidx.lifecycle.ViewModel;

import com.robertgolden.inventory.data.Item;

public class EditItemViewModel extends ViewModel {

    private Item dataSource;

    public EditItemViewModel(){

    }

    public void GetInstance(Context context) {
        dataSource = new Item(context);
    }
}
