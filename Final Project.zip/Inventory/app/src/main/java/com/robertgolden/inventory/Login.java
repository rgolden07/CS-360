package com.robertgolden.inventory;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {


}
