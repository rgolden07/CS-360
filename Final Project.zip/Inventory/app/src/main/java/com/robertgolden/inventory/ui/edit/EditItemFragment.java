package com.robertgolden.inventory.ui.edit;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.robertgolden.inventory.R;
import com.robertgolden.inventory.data.Item;



public class EditItemFragment extends Fragment implements TextWatcher{
    public static final String ARG_ITEM_ID = "edit_item";
    private Item item;

    private EditItemViewModel editItemViewModel;



    /*@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        int itemID = 1;

        Bundle arg = getArguments();
        if(arg != null) {
            itemID = arg.getInt(ARG_ITEM_ID);
        }

        //item = ItemService.getInstance(requireContext()).getItem(itemID);

    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        editItemViewModel = new ViewModelProvider(this).get(EditItemViewModel.class);
        editItemViewModel.GetInstance(getContext());

        View root = inflater.inflate(R.layout.fragment_edit_item, container, false);

        TextView descTextView = root.findViewById(R.id.selectedDesc);
        //descTextView.setText();
        TextView partNumberTextView = root.findViewById(R.id.selectedPN);
        //partNumberTextView.setText(item.getItemPN());
        EditText qtyEdit = root.findViewById(R.id.qtyEdit);
        //qtyEdit.setText(item.getItemQty());
        EditText locEdit = root.findViewById(R.id.locEdit);
        //locEdit.setText(item.getItemLoc());
        Button editButton = root.findViewById(R.id.edit_item_button);
        editButton.setOnClickListener(this::updateItem);

        //TODO implement onclick listener for qty edit and loc edit
        if(item != null) {
            qtyEdit.addTextChangedListener(this);
            locEdit.addTextChangedListener(this);

        }
        return root;
    }

    public void updateItem(@NonNull View view) {
        //TODO FIX THIS
        //item.setItemQty(String.valueOf(R.id.qtyEdit));
        //item.setItemLoc(String.valueOf(R.id.locEdit));
        //getActivity().onBackPressed();
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
