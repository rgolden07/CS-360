package com.robertgolden.inventory.ui.add;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.robertgolden.inventory.R;


import java.util.ArrayList;


public class AddItemFragment extends Fragment implements TextWatcher {

    public EditText newPN;
    public EditText newDesc;
    public EditText newLoc;
    public EditText newQty;
    public Button addItemButton;
    private AddItemViewModel addViewModel;




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        addViewModel = new ViewModelProvider(this).get(AddItemViewModel.class);
        addViewModel.GetInstance(getContext());



        View root = inflater.inflate(R.layout.fragment_add_item, container, false);

        newPN = root.findViewById(R.id.newPN);
        newPN.addTextChangedListener(this);

        newDesc = root.findViewById(R.id.newDesc);
        newDesc.addTextChangedListener(this);

        newLoc = root.findViewById(R.id.newLoc);
        newLoc.addTextChangedListener(this);

        newQty = root.findViewById(R.id.newQty);
        newQty.addTextChangedListener(this);

        addItemButton = root.findViewById(R.id.add_item_button);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addViewModel.AddData(newPN.getText().toString(), newDesc.getText().toString(),
                        newQty.getText().toString(), newLoc.getText().toString());
                getActivity().onBackPressed();
            }
        });



        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }


}
