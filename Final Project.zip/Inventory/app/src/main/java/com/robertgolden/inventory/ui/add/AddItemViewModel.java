package com.robertgolden.inventory.ui.add;

import android.content.Context;

import androidx.lifecycle.ViewModel;

import com.robertgolden.inventory.data.Item;

public class AddItemViewModel extends ViewModel {


    private Item data;

    public AddItemViewModel(){

    }
    public void GetInstance(Context context) {data = new Item(context);}
    public void AddData(String pN, String desc, String qty, String loc) {
        data.insertItemDatabase(pN, desc, qty, loc);

    }
}
