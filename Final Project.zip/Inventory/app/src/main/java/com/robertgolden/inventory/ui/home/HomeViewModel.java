package com.robertgolden.inventory.ui.home;

import android.content.Context;
import android.database.Cursor;
import android.provider.BaseColumns;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.robertgolden.inventory.data.DatabaseContract;
import com.robertgolden.inventory.data.DatabaseHelper;
import com.robertgolden.inventory.data.Item;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class HomeViewModel extends ViewModel {

    private Item dataSource;
    public HomeViewModel() { }

    // Initialize the Data Source  Provider
    public void GetInstance(Context context) {
        dataSource = new Item(context);
    }

    public ArrayList<HashMap> GetInventory() throws IOException {
        try {
            // Projection
            String[] projection = {
                    BaseColumns._ID,
                    DatabaseContract.ItemDataTable.COLUMN_NAME_PARTNUMBER,
                    DatabaseContract.ItemDataTable.COLUMN_NAME_DESCRIPTION,
                    DatabaseContract.ItemDataTable.COLUMN_NAME_QUANTITY,
                    DatabaseContract.ItemDataTable.COLUMN_NAME_LOCATION
            };
            // Query Db
            Cursor cursor = dataSource.queryItemDatabase(projection, null, null, null);
            return DatabaseHelper.GetAll(cursor);
        } catch (Exception e) {
            throw new IOException("Error getting all records", e);
        }
    }
}