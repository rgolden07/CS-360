package com.robertgolden.inventory.ui.notification;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.robertgolden.inventory.R;


public class NotificationFragment extends Fragment implements View.OnClickListener {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        Button switch1 = root.findViewById(R.id.switch1);
        switch1.setOnClickListener(this);


        return root;
    }

    @Override
    public void onClick(View view) {

    }
}
