package com.example.robertgolden;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements TextWatcher {

    EditText nameText;
    Button buttonSayHello;
    TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello.setEnabled(false);
        nameText = findViewById(R.id.nameText);
        nameText.addTextChangedListener(this);

        nameText.setOnFocusChangeListener((view, b) -> {
            if (b) {
                nameText.getText().clear();
            }
            else {
                nameText.setText(R.string.yourName);
            }

        });

    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(@NonNull CharSequence charSequence, int i, int i1, int i2) {
        buttonSayHello.setEnabled(charSequence.length() >0);
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }


    public void SayHello(View view) {
        if (nameText.getText().length() == 0) {
            textGreeting.setText(R.string.emptyName);
        } else if (nameText.getText().toString().startsWith(" ")) {
            textGreeting.setText(R.string.emptyName);
        }
        else {
            textGreeting.setText(R.string.Hello);
            textGreeting.append(" " + nameText.getText().toString());
        }

    }


}